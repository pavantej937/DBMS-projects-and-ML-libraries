var awsIot = require('aws-iot-device-sdk');

/*
var device=awsIot.device({
    keyPath:'5a26619c73-private.pem.key',
    certPath:'5a26619c73-certificate.pem.crt',
    caPath:'rootCA.pem',
    clientId:'MyBus',
    region:'ap-southeast-1'



});
*/
var device = awsIot.device({
    keyPath:'9e0ec6c32d-private.pem.key' ,
    certPath: '9e0ec6c32d-certificate.pem.crt',
    caPath: 'rootCA.pem',
    clientId:'DemoAIIoT',
    host:'a2vd7dr26t9fcj.iot.ap-southeast-1.amazonaws.com'
});

var contents ="Started.....!!!!";

device
    .on('connect',function () {

        console.log('connect');
        //device.subscribe(busPolicy);
        device.publish('$aws/things/DemoAIIoT/shadow/update',JSON.stringify({"state":{"reported":{"test_value1":29, "test_value2":299,"test_value3":96}}}));
        console.log('Message Sent...');

    });

device
    .on('message',function (topic,payload) {
        console.log('message',topic,payload.toString());

    });