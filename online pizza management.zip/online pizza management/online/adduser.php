
<form action="adduser-exec.php" method="post" name="abc">
			User Name: <input type="text" name="username"><br>
			Password: <input type="text" name="password">
			<br><input name="" type="submit" value="Save" />
</form>
			
			
			
