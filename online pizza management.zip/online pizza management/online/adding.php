<form action="adding-exec.php" method="post" name="abc">
			Ingredient Name: <input type="text" name="ingname">
			<br><input name="" type="submit" value="Save" />
</form>