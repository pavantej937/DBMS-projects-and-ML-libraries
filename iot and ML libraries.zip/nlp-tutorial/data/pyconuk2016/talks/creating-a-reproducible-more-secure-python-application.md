title: 'Creating a reproducible more secure python application'
subtitle:
speaker: tessa-alexander
---
Introduce the python environment wrapper and packing tools; virtualenv & pip.

Show you how you can stay up to date by using in requires.io egg security and update checking.

Cover Fabric a python deployment tool and wider systems and workflow replication with Vagrant and Reprozip.

If time allowing touch upon test driven development and adding Travis to your project.