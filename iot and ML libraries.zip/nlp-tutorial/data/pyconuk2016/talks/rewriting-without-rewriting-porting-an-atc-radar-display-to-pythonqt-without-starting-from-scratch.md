title: 'Rewriting without rewriting - porting an ATC radar display to Python/Qt without starting from scratch'
subtitle:
speaker: jim-hague
---
Take an application based on a 20 year old proprietary graphics library and scripting language. We needed to move to something more modern, but a ground-up rewrite was impossible for several business reasons. This is the story of how the application was moved to Python/Qt piece by piece. If it's been a while since you saw a Motif dialog, come and refresh your memory.