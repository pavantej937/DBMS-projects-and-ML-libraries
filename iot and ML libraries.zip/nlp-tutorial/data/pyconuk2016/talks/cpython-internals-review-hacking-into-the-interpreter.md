title: 'CPython Internals Review: Hacking into the Interpreter'
subtitle:
speaker: aleksandr-olegovich-koshkin
---
