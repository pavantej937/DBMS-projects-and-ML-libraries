title: How to land the right job for you
speaker: stevie-buckley
---
In this workshop, Stevie will take you on a tour behind the wizard's curtain and tell you exactly what employers are looking for from a CV and how to nail an interview. He will show you what red flags to watch out for and provide you with questions guaranteed to impress (or possibly terrify) your future employer.
