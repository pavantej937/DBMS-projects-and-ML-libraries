<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>login form</title>
<style type="text/css">
<!--
.style1 {
	font-family: "Times New Roman", Times, serif;
	font-weight: bold;
	font-size: 36px;
}
.style2 {
	font-size: 24px;
	font-weight: bold;
	font-family: "Times New Roman", Times, serif;
}
-->
</style>
</head>
<body>
<p align="center" class="style1 style1">ARE YOU THE ADMIN?</p>
<p align="center" class="style1 style1">&nbsp;</p>
<p align="center" class="style1 style1">&nbsp;</p>
<table width="600" align="center" bgcolor="#999999">
<form id="form1" name="form1" method="post" action="index.php">
	<tbody>
			<tr>
				<td colspan="3"><div align="center"><span class="style2">Log in Here!</span>
				    </div>
			  <hr size="1" noshade="noshade"></td>
			</tr>
			<tr>
				<td align="right">Username </td>
				<td>*</td>
				<td nowrap="nowrap">
				  <input type="text" name="username" />				  				</td>
			</tr>
			<tr>
				<td align="right">Password </td>
				<td>*</td>
				<td nowrap="nowrap">
				  <input type="password" name="password" />				  				</td>
			</tr>
			<tr>
			  <td colspan="3"><input type="submit" name="Submit" value="OK"/>
		      <hr size="1" noshade="noshade"></td>
			</tr>
			</tbody>
</form>
</table>
</body>
</html>
